/*
 * mmu_fb.h - BIOS header & entry table
 *
 * Copyright (C) 2010 Ubiquitous Corp. All rights reserved.
 */

#ifndef _MMU_FB_H
#define _MMU_FB_H

/**
 * \mainpage MMU library Document
 *
 * \section whats_this What's this?
 *
 * MMU library は MMU を操作する関数群です。MMUテーブルの作成や、MMUの有効/無効
 * を行うことができます。
 *
 * \section howto How to use MMU library
 *
 * 使用する関数は以下の 4 つのみです。
 *
 *  \li mmu_init()
 *  \li mmu_set_entry()
 *  \li mmu_enable()
 *  \li mmu_disable()
 *
 * mmu_init() 関数で MMU テーブルを作成するアドレスを指定し、テーブルを初期化します。
 *
 * その後、 mmu_set_entry() 関数を使い、必要なメモリマッピングを行います。
 *
 * MMU テーブルが完成したら、 mmu_enable() 関数で MMU を有効化します。
 *
 * MMU を無効化したい場合は mmu_disable() 関数を使用します。
 *
 * MMU library の使用例は example.c を参照ください。
 *
 * <b> Copyright (C) 2010 Ubiquitous Corp. All rights reserved. </b>
 *
 */

#define AT_CACHEABLE	(1 << 3)
#define AT_BUFFERABLE	(1 << 2)
#define AT_AP_RW		(3 << 10)
#define AT_AP_RO		(0 << 10)

#define AT_MEMORY		(AT_AP_RW | AT_CACHEABLE | AT_BUFFERABLE)
#define AT_PERIFERAL	(AT_AP_RW)

/**
 * Create and initialize MMU table.
 *
 * \param table_phys_addr	Physical address of MMU table to create.
 *
 * This function create and initialize the MMU table to speficied address.
 * It is necessary to call this function earlier than other functions in this
 * library.
 *
 * The entry of each MMU table is initialized that physical address is equal to
 * virtual address, and all entries are set non-cacheable and non-bufferable.
 *
 * ex.
\verbatim
virt. addr   ->   phys. addr
0x000xxxxx   ->   0x000xxxxx
0x001xxxxx   ->   0x001xxxxx
    :        :         :
0xFFExxxxx   ->   0xFFExxxxx
0xFFFxxxxx   ->   0xFFFxxxxx
# all entries are Non-Cacheable, Non-Bufferable
\endverbatim
 */
void mmu_init(unsigned int table_phys_addr);

/**
 * Set a MMU table entry.
 *
 * \param virt_addr		Virtual address
 * \param phys_addr		Physical address
 * \param attribute		MMU entry attribute (Cacheable, bufferable, etc..)
 *
 * mmu_init() で作成した MMU テーブルのエントリを変更する関数です。
 * virt_addr で指定した仮想アドレスを phys_addr で指定した物理アドレスに
 * マッピングします。
 *
 * attribute には \ref AT_CACHEABLE, \ref AT_BUFFERABLE, AT_AP_??? を OR
 * したものを指定します。よく使われる組み合わせは \ref AT_MEMORY,
 * \ref AT_PERIFERAL として定義されています。
 * 多くの場合、\ref AT_MEMORY と \ref AT_PERIFERAL のどちらかを指定すれば
 * いいでしょう。
 *
 * \ref AT_MEMORY は RW で cacheable, bufferable 指定になっています。
 * SDRAM 等の RAM のマップに使用します。
 *
 * \ref AT_PERIFERAL は RW で、NON-cachable, NON-bufferable として定義されて
 * います。キャッシングされては困るペリフェラルの領域の指定に使用します。
 *
 * \attention
 * virt_addr, phys_addr は 1MB 単位の指定しか対応していません。
 */
void mmu_set_entry(unsigned int virt_addr, unsigned int phys_addr,
				   unsigned int attribute);

/**
 * Enable MMU
 *
 * This function enable MMU with the MMU table is created by mmu_init() and
 * mmu_set_entry().
 *
 * Also, I-Cache and D-Cache are enabled.
 */
void mmu_enable(void);

/**
 * Disable MMU
 *
 * This function disable MMU, I-Cache and D-Cache.
 */
void mmu_disable(void);

/**
 * create MMU Table
 * 
 * This function create page table entory for ARM
 */
void mmu_create_table(unsigned int mmu_table_addr);

#endif /* _MMU_FB_H */
