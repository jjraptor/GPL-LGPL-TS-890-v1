/*
 * mmu_fb.c - BIOS header & entry table
 *
 * Copyright (C) 2010 Ubiquitous Corp. All rights reserved.
 */
#include <common.h>
#include <asm/arch/omap3.h>
#include <asm/arch-omap3/sys_proto.h>
#include <mmu_fb.h>

static unsigned int *base;

#define ARM_L1_ENTRIES 4096

#define MMU_SECTION_SHIFT		(20)
#define MMU_SECTION_SIZE		(1 << MMU_SECTION_SHIFT)
#define SECTION_ADDR_MASK		(~((1 << 20) - 1))

#define L1_SECTION		0x02
//#define L1_SECTION		0x12

#define CONT_I_CACHE	(1 << 12)
#define CONT_D_CACHE	(1 << 2)
#define CONT_MMU		(1 << 0)

#define SIZE_1M             0x00100000

#define SDRAM_SIZE				(0x10000000)	/* 256MB */
#define SDRAM_PADDR				(0x80000000)
#define SDRAM_VADDR				(0xc0000000)

void mmu_init(unsigned int mmu_table_addr)
{
	int i;
	unsigned int addr = 0;

	base = (unsigned int *)mmu_table_addr;

	for (i = 0; i < ARM_L1_ENTRIES; i++) {
		mmu_set_entry(addr, addr, AT_PERIFERAL);
		addr += MMU_SECTION_SIZE;
	}
}

void mmu_set_entry(unsigned int virt_addr, unsigned int phys_addr,
				   unsigned int attribute)
{
	unsigned int sect = (virt_addr >> MMU_SECTION_SHIFT);

	if ((virt_addr & ~SECTION_ADDR_MASK) ||
		(phys_addr & ~SECTION_ADDR_MASK)) {
		/* FATAL!! This routine support the section entry (1MB) only!! */
		while (1)
			;
	}

	base[sect] = ((phys_addr & SECTION_ADDR_MASK) | 
					attribute | L1_SECTION);
}

void mmu_enable(void)
{
	/* Must invalidate dcache before enable L2 cache. */ 
	invalidate_dcache(0x3);

	__asm__ __volatile__ (
		"mrc p15, 0, r0, c1, c0, 0;"
		"orr r0, r0, #0x1000;"			/* enable I bit */
		"mcr p15, 0, r0, c1, c0, 0;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"

		"mcr p15, 0, %0, c2, c0, 0;"	/* set TTBR0 */

		"mcr p15, 0, %1, c8, c7, 0;"	/* invalidate all TLB */
		"dsb;"
		"isb;"

		"ldr r0,=0xffffffff		  ;"
		"mcr p15, 0, r0, c3, c0, 0;"	/* Domain access control. 0b11=Manager 0b01=Client*/

		"mrc p15, 0, r0, c1, c0, 0;"
		"orr r0, r0, #0x1;"				/* enable M bit */
		"mcr p15, 0, r0, c1, c0, 0;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"

		"mrc p15, 0, r0, c1, c0, 1;"
		"orr r0, r0, #0x2;"				/* Aux Control Register L2EN bit */
		"mcr p15, 0, r0, c1, c0, 1;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"

		"mrc p15, 0, r0, c1, c0, 0;"
		"orr r0, r0, #0x4;"				/* enable C bit */
		"mcr p15, 0, r0, c1, c0, 0;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		: : "r"(base), "r"(0) : "r0");
}

void mmu_disable(void)
{
	unsigned int type, actrl, ctrl;

	type = get_device_type();
	actrl = ~(0x2);
	ctrl  = ~((1 << 2) | (1 << 0));

	__asm__ __volatile__ (
		"bl falcon_dcache_flush;"

		"mrc p15, 0, r0, c1, c0, 1;"
		"and r0, r0, %1;"				/* Disable L2EN bit */
		"mcr p15, 0, r0, c1, c0, 1;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"

		"mrc p15, 0, r0, c1, c0, 0;"
		"and r0, r0, %2;"				/* Disable C+M bit */
		"mcr p15, 0, r0, c1, c0, 0;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		"nop;"
		: : "r"(type), "r"(actrl), "r"(ctrl) : "r0");
}

void mmu_create_table(unsigned int mmu_table_addr)
{
	unsigned int offset_addr;
	unsigned int end_addr;

	/* Setup Pagetabel of the MMU */
	/* init table */
	mmu_init(mmu_table_addr);

	/* set memory area */
	end_addr = SDRAM_SIZE;
	offset_addr = 0x0;
	while(offset_addr < end_addr){
		mmu_set_entry((SDRAM_VADDR + offset_addr),
					(SDRAM_PADDR + offset_addr), AT_MEMORY);
		offset_addr += MMU_SECTION_SIZE;
	}	

	mmu_set_entry(0x00000000, SDRAM_PADDR, AT_MEMORY);
}
