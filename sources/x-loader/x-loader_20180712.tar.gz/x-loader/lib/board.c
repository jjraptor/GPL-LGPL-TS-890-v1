/*
 * Copyright (C) 2005 Texas Instruments.
 *
 * (C) Copyright 2004
 * Jian Zhang, Texas Instruments, jzhang@ti.com.
 *
 * (C) Copyright 2002
 * Wolfgang Denk, DENX Software Engineering, wd@denx.de.
 *
 * (C) Copyright 2002
 * Sysgo Real-Time Solutions, GmbH <www.elinos.com>
 * Marius Groeger <mgroeger@sysgo.de>
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include <malloc.h>
#include <common.h>
#include <asm/arch/mem.h>
#include <asm/arch/sys_proto.h>
#include <asm/arch/gpio.h>
#include <part.h>
#include <fat.h>

extern int misc_init_r (void);
#define MACH_TYPE_TS890		( 3239 )

#define LOAD_ADDR_INITRAMFS	( 0x87000000 )

char *cmdline_update = "console=ttyO2 root=/dev/ram0 quiet";
#define V_CMDLINE_UPDATE_LENGTH	( 34 )

char *cmdline_normal = "console=ttyO2 root=/dev/fsd3 ro rootfstype=ext4 rootwait no_console_suspend quiet";
#define V_CMDLINE_NORMAL_LENGTH	( 81 )

unsigned char bootargs_buf[128];

/*-----------------------------------------------------------------------
 * Physical Memory Map
 */
#define PHYS_SDRAM_1		OMAP34XX_SDRC_CS0
#define PHYS_SDRAM_1_SIZE	(256 << 20)	/* at 256 MiB */

extern block_dev_desc_t *mmc_get_dev(int dev);

static void setup_start_tag ( struct tag *boot_params );
static void setup_revision_tag( void );
static void setup_memory_tags ( void );
static void setup_commandline_tag ( char *commandline, const unsigned int length );
static void setup_initrd_tag ( unsigned long initrd_start, unsigned long initrd_end );
static void setup_end_tag ( void );

static struct tag *params;

#ifdef CFG_PRINTF
int print_info(void)
{
	printf("\n\nTexas Instruments X-Loader 1.51 ("
			__DATE__ " - " __TIME__ ")\n");
	return 0;
}
#endif

/**
 * Initialize available memory
 */
int mem_init(void)
{
	emif_init();

	return 0;
}

typedef int (init_fnc_t) (void);

init_fnc_t *init_sequence[] = {
	board_init,		/* basic board dependent setup */
#ifdef CFG_PRINTF
 	serial_init,		/* serial communications setup */
	print_info,
#endif
	gpmc_init,		/* board specific gpmc init */
	mem_init,		/* board specific memory init */
	mmc_init,		/* board specific mmc init */
  	NULL,
};

void start_armboot (void)
{
  	init_fnc_t **init_fnc_ptr;
	uchar *buf;
	unsigned int *trace;
	unsigned int boot_device;
	uint boot_params = (OMAP34XX_SDRC_CS0 + 0x100);
	void	(*theKernel)(int zero, int arch, uint params);
	int afprog;
	block_dev_desc_t *dev_desc = NULL;
	long size = 0;
	int nor_boot_flg = 0;

   	for (init_fnc_ptr = init_sequence; *init_fnc_ptr; ++init_fnc_ptr) {
		if ((*init_fnc_ptr)() != 0) {
			hang ();
		}
	}

	misc_init_r();
	buf =  (uchar*) CFG_LOADADDR;

	/* Checking boot device */
	trace = (unsigned int *)0x4020FFB4;
	boot_device = *trace;
	if(0 != (boot_device & BOOT_DEV_MMC1)) {
		printf("\nStarting X-loader on SD Crad \n");
        } else if(0 != (boot_device & BOOT_DEV_XIP)) {
                printf("\nStarting X-loader on NOR Flash \n");
		nor_boot_flg = 1;
	}
#ifdef CONFIG_FALCON
	extern int do_quickboot(void);
	do_quickboot();
#endif
	/* Always first try mmc without checking boot pins */
	buf += mmc_boot(buf);

	if (buf == (uchar *)CFG_LOADADDR)
		hang();

	if(1 == nor_boot_flg) {
		afprog = omap_get_gpio_datain(186);
		if( 1 == afprog ) {
			/* Load initramfs */
			dev_desc = mmc_get_dev(0);
			fat_register_device(dev_desc, 1);
			size = file_fat_read("initfs", (uchar *)LOAD_ADDR_INITRAMFS, 0);
			if( -1 == size ) {
				hang();
			}
		}
	}

	/* go run Linux Kernel and never return */
	setup_start_tag ( (struct tag *)boot_params );
	setup_revision_tag ();
	setup_memory_tags ();
	if( (1 == nor_boot_flg) && (1 == afprog) ) {
		setup_commandline_tag ( cmdline_update, V_CMDLINE_UPDATE_LENGTH );
		if( size > 0 ) {
			setup_initrd_tag ( LOAD_ADDR_INITRAMFS, LOAD_ADDR_INITRAMFS + size );
		}
	} else {
		dev_desc = mmc_get_dev(0);
		fat_register_device(dev_desc, 1);
		size = file_fat_read("bootargs", &bootargs_buf[0], sizeof(bootargs_buf));
		if( size > 0 ) {
			setup_commandline_tag ( (char *)&bootargs_buf[0], size );
		} else {
			setup_commandline_tag ( cmdline_normal, V_CMDLINE_NORMAL_LENGTH );
		}
	}
	setup_end_tag ();
	theKernel = (void (*)(int, int, uint))CFG_LOADADDR;
#ifndef CONFIG_FALCON
	cleanup_before_linux();
#endif
/*	for (;;); */ /* ICE用 */
	theKernel (0, MACH_TYPE_TS890, boot_params); 

	/* should never come here */
}

void hang (void)
{
	/* call board specific hang function */
	board_hang();

	/* if board_hang() returns, hange here */
	printf("X-Loader hangs\n");
	for (;;);
}

static void setup_start_tag (struct tag *boot_params)
{
	params = boot_params;

	params->hdr.tag = ATAG_CORE;
	params->hdr.size = tag_size (tag_core);

	params->u.core.flags = 0;
	params->u.core.pagesize = 0;
	params->u.core.rootdev = 0;

	params = tag_next (params);
}

static void setup_memory_tags ( void )
{
	params->hdr.tag = ATAG_MEM;
	params->hdr.size = tag_size (tag_mem32);

	params->u.mem.start = PHYS_SDRAM_1;
	params->u.mem.size = PHYS_SDRAM_1_SIZE;

	params = tag_next (params);
}

static void setup_commandline_tag ( char *commandline, const unsigned int length )
{
        params->hdr.tag = ATAG_CMDLINE;
        params->hdr.size =
                (sizeof (struct tag_header) + length + 1 + 4) >> 2;

        memcpy ((void *)params->u.cmdline.cmdline, (const void *)commandline, (size_t)length);
	*( params->u.cmdline.cmdline + length ) = '\0';

        params = tag_next (params);
}

static void setup_initrd_tag ( unsigned long initrd_start, unsigned long initrd_end )
{
        /* an ATAG_INITRD node tells the kernel where the compressed
         * ramdisk can be found. ATAG_RDIMG is a better name, actually.
         */
        params->hdr.tag = ATAG_INITRD2;
        params->hdr.size = tag_size (tag_initrd);

        params->u.initrd.start = initrd_start;
        params->u.initrd.size = initrd_end - initrd_start;

        params = tag_next (params);
}

static void setup_revision_tag( void )
{
	params->hdr.tag = ATAG_REVISION;
	params->hdr.size = tag_size (tag_revision);

	params->u.revision.rev = 0x20;

	params = tag_next (params);
}

static void setup_end_tag ( void )
{
	params->hdr.tag = ATAG_NONE;
	params->hdr.size = 0;
}
