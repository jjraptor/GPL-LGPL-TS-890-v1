/*
 * (C) Copyright 2011
 * Ubiquitous.co.,ltd
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include <common.h>
#include <part.h>
#include <fat.h>
#include <mmc.h>
#include <mmu_fb.h>
#include <asm/io.h>
#include <asm/arch/mem.h>
#include <asm/arch/cpu.h>
#include <asm/arch/sys_proto.h>
#include <asm/arch/gpio.h>

#define BIOS_SIZE				(0x20000)	/* 128KB */
#define BIOS_VADDR				(0xcfbe0000)
#define BIOS_PADDR				(0x8fbe0000)

#define SBIOS_SIZE				(0x10000)	/* 64KB */
#define SBIOS_VADDR				(BIOS_VADDR - SBIOS_SIZE)
#define SBIOS_PADDR				(BIOS_PADDR - SBIOS_SIZE) 

#define BIOS_MMU_TBL_ADDR		((BIOS_PADDR + BIOS_SIZE) - 0x4000)

#define PAGE_SIZE       0x1000
#define PAGE_MASK       (~(PAGE_SIZE-1))
#define PAGE_ALIGN(x)   (((x) + PAGE_SIZE - 1) & PAGE_MASK)

#ifndef FBOOT_WB_SIZE
#define FBOOT_WB_SIZE   (PAGE_SIZE * 1)
#endif

#define DPRINT(x)
//#define DPRINT(x) printf(x)

extern block_dev_desc_t *mmc_get_dev(int dev);

/*
 * qb APIs
 */
int call_bios_init(int arg, unsigned long sbios_addr)
{
	int ret;
	void *buff = (void *)0xc8000000;
	int size = PAGE_ALIGN(FBOOT_WB_SIZE) / PAGE_SIZE;

	__asm__ __volatile__ (
		"mov r0, %1\n\t"
		"mov r1, %2\n\t"
		"mov r2, %3\n\t"
		"mov r3, %4\n\t"
		"swi 0x1\n\t"
		"mov %0, r0\n\t"
		:"=r"(ret)
		:"r"(arg), "r"(sbios_addr), "r"(buff), "r"(size)
		:"r0", "r1", "r2", "r3", "r14", "cc", "memory"
	);

	if (ret) {
		printf("BIOS initialization is failed.(%x)\n", ret);
		return -1;
	}

	return 0;
}

void call_quickboot(void)
{
	__asm__ __volatile__(
		"swi 0x2\n"
	);
}

int call_is_valid_image(void)
{
	int ret = 0;

	__asm__ __volatile__(
		"swi 0x3\n\t"
		"mov %0, r0\n\t"
		: "=r"(ret)
		:
		: "r0", "r14", "cc", "memory"
	);

	return ret;
}

unsigned int get_vector_base(void)
{
	unsigned int control;

	__asm__ __volatile__ (
		"mrc p15, 0, %0, c1, c0, 0\n"
		: "=r"(control)
		:
		:"cc"
	);

	return (control & (1 << 13)) ? 0xffff0000 : 0x00000000;
}

int hook_vector(int offset, unsigned long bios_addr)
{
	volatile unsigned int *vector = (u32 *)(get_vector_base() + offset); /* SVC vector */
	volatile unsigned int *addr = vector + 0x20 / 4;
	unsigned int org_vector;
	int i;

	for (i = 0; i < 0x100; i++) {
		if (!addr[0] && !addr[1])
			break;
		addr++;
	}

	if (*addr) {
		printf("Fatal: QB workarea is not found.\n");
		return -1;
	}

	/* set BIOS vector addr */
	*addr = bios_addr + offset;

	/* set Jump code */
	org_vector = *vector;

	*vector = 0xe59ff000 | ((u32)addr - (u32)vector - 8);

	__asm__ __volatile__ (
		"mcr p15, 0, %0, c7, c10, 1\n"	// D-cache clean by MVA
		"mcr p15, 0, %1, c7, c5, 0\n"	// Invalidate I-Cache
		:
		:"r"(vector), "r"(0)
		:"cc"
	);

	return 0;
}

void set_vector_base(void)
{
	unsigned long control;

	__asm__ __volatile__ (
		"mcr p15, 0, %0, c12, c0, 0\n"
		:
		: "r"(0)
		: "cc"
	);

	__asm__ __volatile__ (
		"mrc p15, 0, %0, c1, c0, 0\n"
		:"=r"(control)
		:
		: "cc"
	);

	control &= ~0x00002000;

	__asm__ __volatile__ (
		"mcr p15, 0, %0, c1, c0, 0\n"
		:
		: "r"(control)
		: "cc"
	);
}

void init_vector(void)
{
	int i;
	volatile unsigned int *addr;

	/* clean vector */
	addr = (unsigned int *)get_vector_base();
	for (i = 0; i < 0x40; i++) {
		*addr = 0x0;
		addr++;
	}

	/* hook vector */ 
	hook_vector(4, BIOS_VADDR);
	hook_vector(8, BIOS_VADDR);
}

/*
 * Do QuickBoot
 */
int do_quickboot(void)
{
	int ret;
	unsigned char *buf;
	int size;
	int afprog;
	block_dev_desc_t *dev_desc = NULL;
	int res_flg;
	int bank=0;
	unsigned int *trace;
        unsigned int boot_device;

	trace = (unsigned int *)0x4020FFB4;
        boot_device = *trace;

	printf("Quick Boot load bios...");

	/* create page table for MMU */
	mmu_create_table(BIOS_MMU_TBL_ADDR);

	/* enable MMU */
	mmu_enable();

	/* load falcon bios */
	buf =  (unsigned char*)(BIOS_PADDR);
	dev_desc = mmc_get_dev(0);
	fat_register_device(dev_desc, 1);
	size = file_fat_read("bios.bin", buf, 0);
	if(size == -1) {
		printf("Failed: MMC/SD load error (bios) !!\n");
		goto cancel_quickboot;
	}

	/* load storage bios */
	buf =  (unsigned char*)(SBIOS_PADDR);
	size = file_fat_read("s-bios.bin", buf, 0);
	if(-1 == size){
		printf("Failed: MMC/SD load error (s-bios) !!\n");
		goto cancel_quickboot;
	}
	printf("done.\n");

	set_vector_base();
	DPRINT("set_vector done.\n");
	init_vector();
	DPRINT("init_vector done.\n");

	printf("Quick Boot check snapshot image...\n");
	ret = call_bios_init(0, SBIOS_VADDR);
	if(ret){
		goto cancel_quickboot;
	}
	ret = call_is_valid_image();
	if (!ret){
		printf("Failed: Invalid snapshot image 1\n");
		goto cancel_quickboot;
	}
	ret = call_bios_init(1, SBIOS_VADDR);
	if(ret){
		goto cancel_quickboot;
	}
	ret = call_is_valid_image();
	if (!ret){
		printf("Failed: Invalid snapshot image 2\n");
		goto cancel_quickboot;
	}

	printf("Quick Boot init...\n");
	res_flg = omap_get_gpio_datain(170);
	if( 1 == res_flg ){
		printf("Set bank = 1\n");
		bank = 1;
	}
	ret = call_bios_init(bank, SBIOS_VADDR);
	if(ret){
		goto cancel_quickboot;
	}
	printf("done.\n");

        if(0 != (boot_device & BOOT_DEV_MMC1)) {
		printf("## SD Card Boot: start!\n");
                goto cancel_quickboot;
	} else {
		afprog = omap_get_gpio_datain(186);
                if( 1 == afprog ){
                        printf("## Update Mode: start!\n");
                        goto cancel_quickboot;
                }
	}
	printf("done.\n");

	printf("## Quick Boot: start!\n");
	call_quickboot();

cancel_quickboot:
	printf ("## QuickBoot: cancel\n");
	mmu_disable();
	l2_cache_enable();

	return 1;
}
