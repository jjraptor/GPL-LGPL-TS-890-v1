/*
 * (C) Copyright 2009
 * Texas Instruments, <www.ti.com>
 * Manikandan Pillai<mani.pillai@ti.com>
 * This file is copied from board/omap3evm/omap3evm.c
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */
#include <common.h>
#include <command.h>
#include <part.h>
#include <fat.h>
#include <asm/arch/cpu.h>
#include <asm/arch/bits.h>
#include <asm/arch/mux.h>
#include <asm/arch/sys_proto.h>
#include <asm/arch/sys_info.h>
#include <asm/arch/clocks.h>
#include <asm/arch/mem.h>
#include <asm/arch/gpio.h>

/* Used to index into DPLL parameter tables */
struct dpll_param {
        unsigned int m;
        unsigned int n;
        unsigned int fsel;
        unsigned int m2;
};

typedef struct dpll_param dpll_param;

#define MAX_SIL_INDEX	3

/* Definitions for EMIF4 configuration values */
#define	EMIF4_TIM1_T_RP		0x3
#define	EMIF4_TIM1_T_RCD	0x3
#define	EMIF4_TIM1_T_WR		0x3
#define	EMIF4_TIM1_T_RAS	0x8
#define	EMIF4_TIM1_T_RC		0xA
#define	EMIF4_TIM1_T_RRD	0x2
#define	EMIF4_TIM1_T_WTR	0x2

#define	EMIF4_TIM2_T_XP		0x2
#define	EMIF4_TIM2_T_ODT	0x2
#define	EMIF4_TIM2_T_XSNR	0x1C
#define	EMIF4_TIM2_T_XSRD	0xC8
#define	EMIF4_TIM2_T_RTP	0x1
#define	EMIF4_TIM2_T_CKE	0x2

#define	EMIF4_TIM3_T_TDQSCKMAX	0x0
#define	EMIF4_TIM3_T_RFC	0x25
#define	EMIF4_TIM3_T_RAS_MAX	0x7

#define	EMIF4_PWR_IDLE		0x2
#define	EMIF4_PWR_DPD_EN	0x0
#define	EMIF4_PWR_PM_EN		0x0
#define	EMIF4_PWR_PM_TIM	0x0

#define	EMIF4_INITREF_DIS	0x0
#define	EMIF4_PASR		0x0
#define	EMIF4_REFRESH_RATE	0x50F

/*
 * SDRAM Config register
 */
#define	EMIF4_CFG_SDRAM_TYP	0x2
#define	EMIF4_CFG_IBANK_POS	0x0
#define	EMIF4_CFG_DDR_TERM	0x2
#define	EMIF4_CFG_DDR2_DDQS	0x1
#define	EMIF4_CFG_DYN_ODT	0x0
#define	EMIF4_CFG_DDR_DIS_DLL	0x0
#define	EMIF4_CFG_CWL		0x0
#define	EMIF4_CFG_SDR_DRV	0x1		/* reduced drive strength */
#define	EMIF4_CFG_NARROW_MD	0x0
#define	EMIF4_CFG_CL		0x5
#define	EMIF4_CFG_ROWSIZE	0x0
#define	EMIF4_CFG_IBANK		0x3
#define	EMIF4_CFG_EBANK		0x0
#define	EMIF4_CFG_PGSIZE	0x2

/*
 * EMIF4 PHY Control 1 register configuration
 */
#define EMIF4_DDR1_RD_LAT	0x6
#define	EMIF4_DDR1_PWRDN_DIS	0x0
#define EMIF4_DDR1_STRBEN_EXT	0x0
#define EMIF4_DDR1_DLL_MODE	0x0
#define EMIF4_DDR1_VTP_DYN	0x0
#define EMIF4_DDR1_LB_CK_SEL	0x0

/*
 * EMIF4 PHY Control 2 register configuration
 */
#define EMIF4_DDR2_TX_DATA_ALIGN	0x0
#define EMIF4_DDR2_RX_DLL_BYPASS	0x0

#define CONTROL_DEVCONF2	(0x48002580)
#define USBOTG_OTGMODE		(0x0000C000)
#define USBOTG_SESSENDEN	(0x00002000)
#define USBOTG_VBUSDETECTEN	(0x00001000)
#define USBOTG_SELINPUTCLKFREQ	(0x00000F00)
#define DO_NOT_OVERRIDEN	(0)
#define SESS_END_ENABLE		(0x00002000)
#define VBUS_DETECT_ENABLE	(0x00001000)
#define USB_PHY_PLL_REF_CLK	(0x00000600)

#define AM3517_IP_SW_RESET	(0x48002598)
#define VPFE_PCLK_SW_RST	(1 << 4)
#define HECC_SW_RST		(1 << 3)
#define VPFE_VBUSP_SW_RST	(1 << 2)
#define CPGMACSS_SW_RST		(1 << 1)
#define USB20OTGSS_SW_RST	(1 << 0)

#define EMAC_MDIO_BASE_ADDR	(0x5C030000)
#define EMAC_MDIO_BUS_FREQ	(166000000)	/* 166 MHZ check */
#define EMAC_MDIO_CLOCK_FREQ	(1000000)	/* 2.0 MHz */

#define MDIO_CONTROL_REG	( 4 )
#define MDIO_ALIVE_REG		( 8 )

#define MDIO_CONTROL_IDLE		(0x80000000)
#define MDIO_CONTROL_ENABLE		(0x40000000)
#define MDIO_CONTROL_FAULT_ENABLE	(0x40000)
#define MDIO_CONTROL_FAULT		(0x80000)

/* Following functions are exported from lowlevel_init.S */
extern dpll_param *get_mpu_dpll_param(void);
extern dpll_param *get_core_dpll_param(void);
extern dpll_param *get_per_dpll_param(void);

extern block_dev_desc_t *mmc_get_dev(int dev);

#define __raw_readl(a)    (*(volatile unsigned int *)(a))
#define __raw_writel(v,a) (*(volatile unsigned int *)(a) = (v))
#define __raw_readw(a)    (*(volatile unsigned short *)(a))
#define __raw_writew(v,a) (*(volatile unsigned short *)(a) = (v))

/* Set MUX for UART, GPMC, SDRC, GPIO */

#define 	MUX_VAL(OFFSET,VALUE)\
		__raw_writew((VALUE), OMAP34XX_CTRL_BASE + (OFFSET));

#define		CP(x)	(CONTROL_PADCONF_##x)

const char kernel_name_800x600[] = "zImage1";
const char kernel_name_848x480[] = "zImage2";

/*******************************************************
 * Routine: delay
 * Description: spinning delay to use before udelay works
 ******************************************************/
static inline void delay(unsigned long loops)
{
	__asm__ volatile ("1:\n" "subs %0, %1, #1\n"
			  "bne 1b":"=r" (loops):"0"(loops));
}

void udelay (unsigned long usecs) {
	delay(usecs);
}

/*****************************************
 * Routine: board_init
 * Description: Early hardware init.
 *****************************************/
int board_init (void)
{
	omap_set_gpio_direction(1,0);	/* GPIO_1 : Unused*/
	omap_set_gpio_dataout(1,0);
	omap_set_gpio_direction(10,1);	/* GPIO_10 : LCDREQ */
	omap_set_gpio_direction(11,0);	/* GPIO_11 : Unused*/
	omap_set_gpio_dataout(11,0);
	omap_set_gpio_direction(12,0);	/* GPIO_12 : HS1EN*/
	omap_set_gpio_dataout(12,1);
	omap_set_gpio_direction(17,0);	/* GPIO_17 : US1SPD*/
	omap_set_gpio_dataout(17,1);
	omap_set_gpio_direction(18,1);	/* GPIO_18 : POLSEL*/
	omap_set_gpio_direction(19,1);	/* GPIO_19 : HS1INT*/
	omap_set_gpio_direction(20,1);	/* GPIO_20 : HS2INT*/
	omap_set_gpio_direction(22,0);	/* GPIO_22 : US1SUS*/
	omap_set_gpio_dataout(22,0);
	omap_set_gpio_direction(24,0);	/* GPIO_24 : US2SUS*/
	omap_set_gpio_dataout(24,0);
	omap_set_gpio_direction(26,0);	/* GPIO_26 : US2SPD */
	omap_set_gpio_dataout(26,1);
	omap_set_gpio_direction(30,0);	/* GPIO_30 : Unused*/
	omap_set_gpio_dataout(30,0);
	omap_set_gpio_direction(31,0);	/* GPIO_31 : Unused*/
	omap_set_gpio_dataout(31,0);
	omap_set_gpio_direction(52,0);	/* GPIO_52 : Unused*/
	omap_set_gpio_dataout(52,0);
	omap_set_gpio_direction(59,0);	/* GPIO_59 : Unused*/
	omap_set_gpio_dataout(59,0);
	omap_set_gpio_direction(60,0);	/* GPIO_60 : Unused*/
	omap_set_gpio_dataout(60,0);
	omap_set_gpio_direction(95,0);	/* GPIO_95 : PANEL_UART_TX */
	omap_set_gpio_dataout(95,0);
	omap_set_gpio_direction(99,1);	/* GPIO_99 : SPISEL*/
	omap_set_gpio_direction(101,0);	/* GPIO_101 : ABLEN */
	omap_set_gpio_dataout(101,0);
	omap_set_gpio_direction(103,0);	/* GPIO_103 : ETnRST */
	omap_set_gpio_dataout(103,0);
	omap_set_gpio_direction(104,1);	/* GPIO_104 : LNGSEL */
	omap_set_gpio_direction(105,0);	/* GPIO_105 : DVIPD */
	omap_set_gpio_dataout(105,1);
	omap_set_gpio_direction(106,0);	/* GPIO_106 : VDACPS */
	omap_set_gpio_dataout(106,0);
	omap_set_gpio_direction(125,1);	/* GPIO_125 : CONSEL */
	omap_set_gpio_direction(126,1);	/* GPIO_126 : SDWP */
	omap_set_gpio_direction(127,1);	/* GPIO_127 : SDDET */
	omap_set_gpio_direction(154,0);	/* GPIO_154 : PDONE */
	omap_set_gpio_dataout(154,0);
	omap_set_gpio_direction(155,0);	/* GPIO_155 : DACnPD */
	omap_set_gpio_dataout(155,0);
	omap_set_gpio_direction(157,1);	/* GPIO_157 : BKC */
	omap_set_gpio_direction(162,0);	/* GPIO_162 : AHLT */
	omap_set_gpio_dataout(162,0);
//	omap_set_gpio_direction(163,0);	/* GPIO_162 : Debug port 1 */
//	omap_set_gpio_dataout(163,0);
//	omap_set_gpio_direction(164,0);	/* GPIO_162 : Debug port 2 */
//	omap_set_gpio_dataout(164,0);
	omap_set_gpio_direction(170,1);	/* GPIO_170 : RESSEL */
	omap_set_gpio_direction(176,0);	/* GPIO_176 : HS2EN*/
	omap_set_gpio_dataout(176,1);
	omap_set_gpio_direction(186,1);	/* GPIO_186 : AFPROG */

	return 0;
}

/* TODO: Move it to common place so that should be used
 * for all OMAP series of devices
 */
u32 is_cpu_family( u16 family )
{
	if (CPU_AM35XX == family)
		return 1;

	return 0;
}
/*************************************************************
 *  get_device_type(): tell if GP/HS/EMU/TST
 *************************************************************/
u32 get_device_type(void)
{
        int mode;
        mode = __raw_readl(CONTROL_STATUS) & (DEVICE_MASK);
        return(mode >>= 8);
}

/************************************************
 * get_sysboot_value(void) - return SYS_BOOT[4:0]
 ************************************************/
u32 get_sysboot_value(void)
{
        int mode;
        mode = __raw_readl(CONTROL_STATUS) & (SYSBOOT_MASK);
        return mode;
}
/*************************************************************
 * Routine: get_mem_type(void) - returns the kind of memory connected
 * to GPMC that we are trying to boot form. Uses SYS BOOT settings.
 *************************************************************/
u32 get_mem_type(void)
{
	u32 order = 0;
        u32 mem_type = get_sysboot_value();

	order = mem_type & BIT5;
	mem_type &= ~BIT5;
	switch (mem_type){

	case 1:
	case 21:
	case 27:
		return GPMC_NAND;

	case 12:
	case 15:
		return MMC_NAND;

	case 13:
		if (order)
			return MMC_NAND;
		else
			return GPMC_NOR;
	case 2:
	case 3:
	case 6:
	case 24:
		return MMC_NAND;
	default:
		return GPMC_NAND;
	}
}

/******************************************
 * get_cpu_rev(void) - extract version info
 ******************************************/
u32 get_cpu_rev(void)
{
	u32 cpuid=0;
	u32 cpu_revision;

	/* On ES1.0 the IDCODE register is not exposed on L4
	 * so using CPU ID to differentiate
	 * between ES2.0 and ES1.0.
	 */
	__asm__ __volatile__("mrc p15, 0, %0, c0, c0, 0":"=r" (cpuid));
	if((cpuid  & 0xf) == 0x0)
	{
	cpu_revision = CPU_3XX_ES10;
	}
	else
	{
		/* Decode the IDs on > ES1.0 */
		cpuid = __raw_readl(OMAP34XX_CONTROL_ID);

		cpu_revision = (cpuid >> CPU_3XX_ID_SHIFT) & 0xf;
	}

	return cpu_revision;
}

/*****************************************************************
 * sr32 - clear & set a value in a bit range for a 32 bit address
 *****************************************************************/
void sr32(u32 addr, u32 start_bit, u32 num_bits, u32 value)
{
	u32 tmp, msk = 0;
	msk = 1 << num_bits;
	--msk;
	tmp = __raw_readl(addr) & ~(msk << start_bit);
	tmp |=  value << start_bit;
	__raw_writel(tmp, addr);
}

/*********************************************************************
 * wait_on_value() - common routine to allow waiting for changes in
 *   volatile regs.
 *********************************************************************/
u32 wait_on_value(u32 read_bit_mask, u32 match_value, u32 read_addr, u32 bound)
{
	u32 i = 0, val;
	do {
		++i;
		val = __raw_readl(read_addr) & read_bit_mask;
		if (val == match_value)
			return (1);
		if (i == bound)
			return (0);
	} while (1);
}

/*********************************************************************
 * emif_init() - Configure EMIF4
 *********************************************************************/
void emif_init(void)
{
	unsigned int regval;

	/* Set the DDR PHY parameters in PHY ctrl registers */
	regval = (EMIF4_DDR1_RD_LAT | (EMIF4_DDR1_PWRDN_DIS << 6) |
		(EMIF4_DDR1_STRBEN_EXT << 7) | (EMIF4_DDR1_DLL_MODE << 12) |
		(EMIF4_DDR1_VTP_DYN << 15) | (EMIF4_DDR1_LB_CK_SEL << 23));
	__raw_writel(regval, EMIF4_DDR_PHYCTL1);
	__raw_writel(regval, EMIF4_DDR_PHYCTL1_SHDW);

	regval = (EMIF4_DDR2_TX_DATA_ALIGN | (EMIF4_DDR2_RX_DLL_BYPASS << 1));
	__raw_writel(regval, EMIF4_DDR_PHYCTL2);

	/* Reset the DDR PHY and wait till completed */
	sr32(EMIF4_IODFT_TLGC, 10, 1, 1);
	/*Wait till that bit clears*/
	while ((__raw_readl(EMIF4_IODFT_TLGC) & BIT10) == 0x1);
	/*Re-verify the DDR PHY status*/
	while ((__raw_readl(EMIF4_SDRAM_STS) & BIT2) == 0x0);

	sr32(EMIF4_IODFT_TLGC, 0, 1, 1);

	/* Perform a VTP calibration *//* from wiki.ti.com */
	regval = __raw_readl(EMIF4_DDR_PHYCTL1);
	regval |= 0x00008000;
	__raw_writel(regval, EMIF4_DDR_PHYCTL1);
	__raw_writel(regval, EMIF4_DDR_PHYCTL1_SHDW);
	while(!(__raw_readl(0x48002584) & 0x00000020));
	regval &= ~0x00008000;
	__raw_writel(regval, EMIF4_DDR_PHYCTL1);
	__raw_writel(regval, EMIF4_DDR_PHYCTL1_SHDW);

	/* Set SDR timing registers */
	regval = (EMIF4_TIM1_T_WTR | (EMIF4_TIM1_T_RRD << 3) |
		(EMIF4_TIM1_T_RC << 6) | (EMIF4_TIM1_T_RAS << 12) |
		(EMIF4_TIM1_T_WR << 17) | (EMIF4_TIM1_T_RCD << 21) |
		(EMIF4_TIM1_T_RP << 25));
	__raw_writel(regval, EMIF4_SDRAM_TIM1);
	__raw_writel(regval, EMIF4_SDRAM_TIM1_SHDW);

	regval = (EMIF4_TIM2_T_CKE | (EMIF4_TIM2_T_RTP << 3) |
		(EMIF4_TIM2_T_XSRD << 6) | (EMIF4_TIM2_T_XSNR << 16) |
		(EMIF4_TIM2_T_ODT << 25) | (EMIF4_TIM2_T_XP << 28));
	__raw_writel(regval, EMIF4_SDRAM_TIM2);
	__raw_writel(regval, EMIF4_SDRAM_TIM2_SHDW);

	regval = (EMIF4_TIM3_T_RAS_MAX | (EMIF4_TIM3_T_RFC << 4) |
		(EMIF4_TIM3_T_TDQSCKMAX << 13));
	__raw_writel(regval, EMIF4_SDRAM_TIM3);
	__raw_writel(regval, EMIF4_SDRAM_TIM3_SHDW);

	/* Set the PWR control register */
	regval = (EMIF4_PWR_PM_TIM | (EMIF4_PWR_PM_EN << 8) |
		(EMIF4_PWR_DPD_EN << 10) | (EMIF4_PWR_IDLE << 30));
	__raw_writel(regval, EMIF4_PWR_MGT_CTRL);
	__raw_writel(regval, EMIF4_PWR_MGT_CTRL_SHDW);

	/* Set the DDR refresh rate control register */
	regval = (EMIF4_REFRESH_RATE | (EMIF4_PASR << 24) |
		(EMIF4_INITREF_DIS << 31));
	__raw_writel(regval, EMIF4_SDRAM_RFCR);
	__raw_writel(regval, EMIF4_SDRAM_RFCR_SHDW);

	/* set the SDRAM configuration register */
	regval = (EMIF4_CFG_PGSIZE | (EMIF4_CFG_EBANK << 3) |
		(EMIF4_CFG_IBANK << 4) | (EMIF4_CFG_ROWSIZE << 7) |
		(EMIF4_CFG_CL << 10) | (EMIF4_CFG_NARROW_MD << 14) |
		(EMIF4_CFG_CWL << 16) | (EMIF4_CFG_SDR_DRV << 18) |
		(EMIF4_CFG_DDR_DIS_DLL << 20) | (EMIF4_CFG_DYN_ODT << 21) |
		(EMIF4_CFG_DDR2_DDQS << 23) | (EMIF4_CFG_DDR_TERM << 24) |
		(EMIF4_CFG_IBANK_POS << 27) | (EMIF4_CFG_SDRAM_TYP << 29));
	__raw_writel(regval, EMIF4_SDRAM_CFG);
}

/*************************************************************
 * get_sys_clk_speed - determine reference oscillator speed
 *  based on known 32kHz clock and gptimer.
 *************************************************************/
u32 get_osc_clk_speed(void)
{
	u32 start, cstart, cend, cdiff, val;

	val = __raw_readl(PRM_CLKSRC_CTRL);
	/* If SYS_CLK is being divided by 2, remove for now */
	val = (val & (~BIT7)) | BIT6;
	__raw_writel(val, PRM_CLKSRC_CTRL);

	/* enable timer2 */
	val = __raw_readl(CM_CLKSEL_WKUP) | BIT0;
	__raw_writel(val, CM_CLKSEL_WKUP);	/* select sys_clk for GPT1 */

	/* Enable I and F Clocks for GPT1 */
	val = __raw_readl(CM_ICLKEN_WKUP) | BIT0 | BIT2;
	__raw_writel(val, CM_ICLKEN_WKUP);
	val = __raw_readl(CM_FCLKEN_WKUP) | BIT0;
	__raw_writel(val, CM_FCLKEN_WKUP);

	__raw_writel(0, OMAP34XX_GPT1 + TLDR);	/* start counting at 0 */
	__raw_writel(GPT_EN, OMAP34XX_GPT1 + TCLR);     /* enable clock */
	/* enable 32kHz source *//* enabled out of reset */
	/* determine sys_clk via gauging */

	start = 20 + __raw_readl(S32K_CR);	/* start time in 20 cycles */
	while (__raw_readl(S32K_CR) < start);	/* dead loop till start time */
	cstart = __raw_readl(OMAP34XX_GPT1 + TCRR);	/* get start sys_clk count */
	while (__raw_readl(S32K_CR) < (start + 20));	/* wait for 40 cycles */
	cend = __raw_readl(OMAP34XX_GPT1 + TCRR);	/* get end sys_clk count */
	cdiff = cend - cstart;				/* get elapsed ticks */

	/* based on number of ticks assign speed */
	if (cdiff > 19000)
		return (S38_4M);
	else if (cdiff > 15200)
		return (S26M);
	else if (cdiff > 13000)
		return (S24M);
	else if (cdiff > 9000)
		return (S19_2M);
	else if (cdiff > 7600)
		return (S13M);
	else
		return (S12M);
}

/******************************************************************************
 * prcm_init() - inits clocks for PRCM as defined in clocks.h
 *   -- called from SRAM, or Flash (using temp SRAM stack).
 *****************************************************************************/
void prcm_init(void)
{
	dpll_param *dpll_param_p;

	/* Gauge the input clock speed and find out the sys_clkin_sel
	 * value corresponding to the input clock.
	 */
	sr32(PRM_CLKSEL, 0, 3, 3); /* set input crystal speed(26MHz) */

	sr32(PRM_CLKSRC_CTRL, 6, 2, 2);/* input clock divider */

	/* Unlock MPU DPLL (slows things down, and needed later) */
	sr32(CM_CLKEN_PLL_MPU, 0, 3, PLL_LOW_POWER_BYPASS);
	wait_on_value(BIT0, 0, CM_IDLEST_PLL_MPU, LDELAY);

	/* Getting the base address of Core DPLL param table*/
	dpll_param_p = (dpll_param *)get_core_dpll_param();
	/* CORE DPLL */
	/* sr32(CM_CLKSEL2_EMU) set override to work when asleep */
	sr32(CM_CLKEN_PLL, 0, 3, PLL_FAST_RELOCK_BYPASS);
	wait_on_value(BIT0, 0, CM_IDLEST_CKGEN, LDELAY);
	sr32(CM_CLKSEL1_EMU, 16, 5, CORE_M3X2);	/* m3x2 */
	sr32(CM_CLKSEL1_PLL, 27, 2, dpll_param_p->m2);	/* Set M2 */
	sr32(CM_CLKSEL1_PLL, 16, 11, dpll_param_p->m);	/* Set M */
	sr32(CM_CLKSEL1_PLL, 8, 7, dpll_param_p->n);	/* Set N */
	sr32(CM_CLKSEL1_PLL, 6, 1, 0);			/* 96M Src */
	sr32(CM_CLKSEL_CORE, 2, 2, CORE_L4_DIV);	/* l4 */
	sr32(CM_CLKSEL_CORE, 0, 2, CORE_L3_DIV);	/* l3 */
	sr32(CM_CLKSEL_SGX, 0, 3, GFX_DIV_36X);		/* CLKSEL_SGX */
	sr32(CM_CLKSEL_WKUP, 1, 2, WKUP_RSM);		/* reset mgr */
	sr32(CM_CLKEN_PLL, 4, 4, dpll_param_p->fsel);	/* FREQSEL */
	sr32(CM_CLKEN_PLL, 0, 3, PLL_LOCK);		/* lock mode */
	wait_on_value(BIT0, 1, CM_IDLEST_CKGEN, LDELAY);

	/* Getting the base address to PER  DPLL param table*/
	dpll_param_p = (dpll_param *)get_per_dpll_param();
	/* PER DPLL */
	sr32(CM_CLKEN_PLL, 16, 3, PLL_STOP);
	wait_on_value(BIT1, 0, CM_IDLEST_CKGEN, LDELAY);
	sr32(CM_CLKSEL1_EMU, 24, 5, PER_M6X2);	/* set M6 */
	sr32(CM_CLKSEL_CAM, 0, 5, PER_M5X2);	/* set M5 */
	sr32(CM_CLKSEL_DSS, 0, 5, PER_M4X2);	/* set M4 */
	sr32(CM_CLKSEL_DSS, 8, 5, PER_M3X2);	/* set M3 */
	sr32(CM_CLKSEL3_PLL, 0, 5, dpll_param_p->m2);	/* set M2 */
	sr32(CM_CLKSEL2_PLL, 8, 11, dpll_param_p->m);	/* set m */
	sr32(CM_CLKSEL2_PLL, 0, 7, dpll_param_p->n);	/* set n */
	sr32(CM_CLKEN_PLL, 20, 4, dpll_param_p->fsel);/* FREQSEL */
	sr32(CM_CLKEN_PLL, 16, 3, PLL_LOCK);	/* lock mode */
	wait_on_value(BIT1, 2, CM_IDLEST_CKGEN, LDELAY);

	/* Getting the base address to MPU DPLL param table*/
	dpll_param_p = (dpll_param *)get_mpu_dpll_param();
	/* MPU DPLL (unlocked already) */
	sr32(CM_CLKSEL2_PLL_MPU, 0, 5, dpll_param_p->m2);	/* Set M2 */
	sr32(CM_CLKSEL1_PLL_MPU, 8, 11, dpll_param_p->m);	/* Set M */
	sr32(CM_CLKSEL1_PLL_MPU, 0, 7, dpll_param_p->n);	/* Set N */
	sr32(CM_CLKEN_PLL_MPU, 4, 4, dpll_param_p->fsel);	/* FREQSEL */
	sr32(CM_CLKEN_PLL_MPU, 0, 3, PLL_LOCK); /* lock mode */
	wait_on_value(BIT0, 1, CM_IDLEST_PLL_MPU, LDELAY);

	/* Set up GPTimers to sys_clk source only */
 	sr32(CM_CLKSEL_PER, 0, 8, 0xff);

	delay(5000);
}

/*****************************************
 * Routine: secure_unlock
 * Description: Setup security registers for access
 * (GP Device only)
 *****************************************/
void secure_unlock(void)
{
	/* Permission values for registers -Full fledged permissions to all */
	#define UNLOCK_1 0xFFFFFFFF
	#define UNLOCK_2 0x00000000
	#define UNLOCK_3 0x0000FFFF
	/* Protection Module Register Target APE (PM_RT)*/
	__raw_writel(UNLOCK_1, RT_REQ_INFO_PERMISSION_1);
	__raw_writel(UNLOCK_1, RT_READ_PERMISSION_0);
	__raw_writel(UNLOCK_1, RT_WRITE_PERMISSION_0);
	__raw_writel(UNLOCK_2, RT_ADDR_MATCH_1);

	__raw_writel(UNLOCK_3, GPMC_REQ_INFO_PERMISSION_0);
	__raw_writel(UNLOCK_3, GPMC_READ_PERMISSION_0);
	__raw_writel(UNLOCK_3, GPMC_WRITE_PERMISSION_0);

	__raw_writel(UNLOCK_3, OCM_REQ_INFO_PERMISSION_0);
	__raw_writel(UNLOCK_3, OCM_READ_PERMISSION_0);
	__raw_writel(UNLOCK_3, OCM_WRITE_PERMISSION_0);
	__raw_writel(UNLOCK_2, OCM_ADDR_MATCH_2);

	__raw_writel(UNLOCK_1, SMS_RG_ATT0); /* SDRC region 0 public */
}

/**********************************************************
 * Routine: try_unlock_sram()
 * Description: If chip is GP type, unlock the SRAM for
 *  general use.
 ***********************************************************/
void try_unlock_memory(void)
{
	int mode;

	/* if GP device unlock device SRAM for general use */
	/* secure code breaks for Secure/Emulation device - HS/E/T*/
	mode = get_device_type();
	if (mode == GP_DEVICE) {
		secure_unlock();
	}
	return;
}

/**********************************************************
 * Routine: s_init
 * Description: Does early system init of muxing and clocks.
 * - Called at time when only stack is available.
 **********************************************************/

void s_init(void)
{
	watchdog_init();
#ifdef CONFIG_3430_AS_3410
	/* setup the scalability control register for
	 * 3430 to work in 3410 mode
	 */
	__raw_writel(0x5ABF,CONTROL_SCALABLE_OMAP_OCP);
#endif
	try_unlock_memory();
	set_muxconf_regs();
	delay(100);
	prcm_init();
	per_clocks_enable();

	/* enable the DDRPHY clk */
	sr32((OMAP34XX_CTRL_BASE + 0x584), 15, 1, 0x1);
	/* enable the EMIF4 clk */
	sr32((OMAP34XX_CTRL_BASE + 0x584), 14, 1, 0x1);
	/* Enable the peripheral clocks */
	sr32((OMAP34XX_CTRL_BASE + 0x59C), 0, 4, 0x3);
	sr32((OMAP34XX_CTRL_BASE + 0x59C), 8, 3, 0x2);

	/* bring SW IP reset */
	sr32((OMAP34XX_CTRL_BASE + 0x598), 0, 5, 0x1F);
}

/*******************************************************
 * Routine: misc_init_r
 * Description: Init ethernet (done here so udelay works)
 ********************************************************/
int misc_init_r (void)
{
	unsigned int reset;

/*	udelay(200); */           /* Wait 25ms(External power supplies at 80% to nRST deassertion) */
	omap_set_gpio_dataout(103,1);

	/* allow the PHY to stabilize and settle down */
	udelay(1);                /* Wait 800ns(Output drive after nRST deassertion) */

	/*ensure that the module is out of reset*/
	reset = __raw_readl(AM3517_IP_SW_RESET);
	reset &= (~CPGMACSS_SW_RST);
	reset &= (~USB20OTGSS_SW_RST);
	__raw_writel(reset, AM3517_IP_SW_RESET);

	dss_init();

	reset = __raw_readl(CONTROL_DEVCONF2);
        reset &= ~(USBOTG_OTGMODE | USBOTG_SESSENDEN | USBOTG_VBUSDETECTEN | USBOTG_SELINPUTCLKFREQ);
        reset |= (DO_NOT_OVERRIDEN | SESS_END_ENABLE | VBUS_DETECT_ENABLE | USB_PHY_PLL_REF_CLK);
        __raw_writel(reset, CONTROL_DEVCONF2);

	return(0);
}

/******************************************************
 * Routine: wait_for_command_complete
 * Description: Wait for posting to finish on watchdog
 ******************************************************/
void wait_for_command_complete(unsigned int wd_base)
{
	int pending = 1;
	do {
		pending = __raw_readl(wd_base + WWPS);
	} while (pending);
}

/****************************************
 * Routine: watchdog_init
 * Description: Shut down watch dogs
 *****************************************/
void watchdog_init(void)
{
	/* There are 3 watch dogs WD1=Secure, WD2=MPU, WD3=IVA. WD1 is
	 * either taken care of by ROM (HS/EMU) or not accessible (GP).
	 * We need to take care of WD2-MPU or take a PRCM reset.  WD3
	 * should not be running and does not generate a PRCM reset.
	 */
	sr32(CM_FCLKEN_WKUP, 5, 1, 1);
	sr32(CM_ICLKEN_WKUP, 5, 1, 1);
	wait_on_value(BIT5, 0x20, CM_IDLEST_WKUP, 5); /* some issue here */

	__raw_writel(WD_UNLOCK1, WD2_BASE + WSPR);
	wait_for_command_complete(WD2_BASE);
	__raw_writel(WD_UNLOCK2, WD2_BASE + WSPR);
}

/**********************************************
 * Routine: dram_init
 * Description: sets uboots idea of sdram size
 **********************************************/
int dram_init (void)
{
	return 0;
}

/*****************************************************************
 * Routine: peripheral_enable
 * Description: Enable the clks & power for perifs (GPT2, UART1,...)
 ******************************************************************/
void per_clocks_enable(void)
{
	/* Enable GPT2 */
	sr32(CM_ICLKEN_PER, 3, 1, 0x1); /* ICKen GPT2 */
	sr32(CM_FCLKEN_PER, 3, 1, 0x1); /* FCKen GPT2 */

	/* Enable GPIO1 clocks */
	sr32(CM_ICLKEN_WKUP, 3, 1, 0x1);
	sr32(CM_FCLKEN_WKUP, 3, 1, 0x1);

	/* Enable GPIO2 clocks */
	sr32(CM_ICLKEN_PER, 13, 1, 0x1);
	sr32(CM_FCLKEN_PER, 13, 1, 0x1);

	/* Enable GPIO3 clocks */
	sr32(CM_ICLKEN_PER, 14, 1, 0x1);
	sr32(CM_FCLKEN_PER, 14, 1, 0x1);

	/* Enable GPIO4 clocks */
	sr32(CM_ICLKEN_PER, 15, 1, 0x1); /* ICKen GPIO4 */
	sr32(CM_FCLKEN_PER, 15, 1, 0x1); /* FCKen GPIO4 */

	/* Enable GPIO5 clocks */
	sr32(CM_ICLKEN_PER, 16, 1, 0x1);
	sr32(CM_FCLKEN_PER, 16, 1, 0x1);

	/* Enable GPIO6 clocks */
	sr32(CM_ICLKEN_PER, 17, 1, 0x1);
	sr32(CM_FCLKEN_PER, 17, 1, 0x1);

#ifdef CFG_NS16550
	/* Enable UART1 clocks */
	sr32(CM_FCLKEN1_CORE, 13, 1, 0x1);
	sr32(CM_ICLKEN1_CORE, 13, 1, 0x1);

	/* Enable UART3 clocks */
	sr32(CM_FCLKEN_PER, 11, 1, 0x1);
	sr32(CM_ICLKEN_PER, 11, 1, 0x1);

	/* Enable UART4 clocks */
	sr32(CM_FCLKEN1_CORE, 23, 1, 0x1);
	sr32(CM_ICLKEN1_CORE, 23, 1, 0x1);
#endif
	/* Enable MMC1 clocks */
	sr32(CM_FCLKEN1_CORE, 24, 1, 0x1);
	sr32(CM_ICLKEN1_CORE, 24, 1, 0x1);

	/* Enable MMC2 clocks */
	sr32(CM_FCLKEN1_CORE, 25, 1, 0x1);
	sr32(CM_ICLKEN1_CORE, 25, 1, 0x1);

	/* Enable I2C1 clocks */
	sr32(CM_FCLKEN1_CORE, 15, 1, 0x1);
	sr32(CM_ICLKEN1_CORE, 15, 1, 0x1);

	/* Enable McSPI1 clocks */
	sr32(CM_FCLKEN1_CORE, 18, 1, 0x1);
	sr32(CM_ICLKEN1_CORE, 18, 1, 0x1);

	/* Enable McBSP2 clocks */
	sr32(CM_FCLKEN_PER, 0, 1, 0x1);
	sr32(CM_ICLKEN_PER, 0, 1, 0x1);

	/* Enable DSS1 clocks */
	sr32(CM_FCLKEN_DSS, 0, 1, 0x1);
	sr32(CM_ICLKEN_DSS, 0, 1, 0x1);

	delay(1000);
}

/*
 * IEN  - Input Enable
 * IDIS - Input Disable
 * PTD  - Pull type Down
 * PTU  - Pull type Up
 * DIS  - Pull type selection is inactive
 * EN   - Pull type selection is active
 * M0   - Mode 0
 * The commented string gives the final mux configuration for that pin
 */
#define MUX_DEFAULT()\
	/* SDRC */\
	MUX_VAL(CP(SDRC_D0),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D1),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D2),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D3),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D4),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D5),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D6),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D7),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D8),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D9),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D10),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D11),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D12),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D13),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D14),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D15),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D16),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D17),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D18),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D19),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D20),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D21),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D22),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D23),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D24),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D25),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D26),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D27),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D28),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D29),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D30),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_D31),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_CLK),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_DQS0),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_CKE0),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(SDRC_DQS1),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_DQS2),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_DQS3),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SDRC_DQS0N),		(IEN  | PTD | EN  | M0)) \
	MUX_VAL(CP(SDRC_DQS1N),		(IEN  | PTD | EN  | M0)) \
	MUX_VAL(CP(SDRC_DQS2N),		(IEN  | PTD | EN  | M0)) \
	MUX_VAL(CP(SDRC_DQS3N),		(IEN  | PTD | EN  | M0)) \
	/*sdrc_strben_dly0*/\
	MUX_VAL(CP(STRBEN_DLY0),	(IEN  | PTD | EN  | M0)) \
	/*sdrc_strben_dly1*/\
	MUX_VAL(CP(STRBEN_DLY1),	(IEN  | PTD | EN  | M0)) \
	/* GPMC */\
	MUX_VAL(CP(GPMC_A1),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_A2),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_A3),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_A4),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_A5),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_A6),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_A7),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_A8),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_A9),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_A10),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_D0),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D1),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D2),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D3),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D4),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D5),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D6),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D7),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D8),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D9),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D10),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D11),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D12),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D13),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D14),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_D15),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_NCS0),		(IDIS | PTU | EN  | M0)) \
	MUX_VAL(CP(GPMC_NCS1),		(IDIS | PTD | EN  | M4)) /*GPIO_52*/\
	MUX_VAL(CP(GPMC_NCS2),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_NCS3),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_NCS4),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_NCS5),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_NCS6),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_NCS7),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_CLK),		(IDIS | PTD | EN  | M4)) /*GPIO_59*/\
	MUX_VAL(CP(GPMC_NADV_ALE),	(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_NOE),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_NWE),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_NBE0_CLE),	(IDIS | PTD | EN  | M4)) /*GPIO_60*/\
	MUX_VAL(CP(GPMC_NBE1),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_NWP),		(IEN  | PTD | EN  | M0)) \
	MUX_VAL(CP(GPMC_WAIT0),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(GPMC_WAIT1),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_WAIT2),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(GPMC_WAIT3),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	/* DSS */\
	MUX_VAL(CP(DSS_PCLK),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_HSYNC),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_VSYNC),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_ACBIAS),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA0),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA1),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA2),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA3),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA4),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA5),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA6),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA7),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA8),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA9),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA10),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA11),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA12),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA13),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA14),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA15),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA16),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA17),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA18),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA19),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA20),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA21),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA22),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(DSS_DATA23),		(IDIS | PTD | DIS | M0)) \
	/* CCDC */\
	MUX_VAL(CP(CCDC_PCLK),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(CCDC_FIELD),		(IDIS | PTD | DIS | M4)) /*GPIO_95*/\
	MUX_VAL(CP(CCDC_HD),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(CCDC_VD),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(CCDC_WEN),		(IEN  | PTD | EN  | M2)) /*UART4_RX*/\
	MUX_VAL(CP(CCDC_DATA0),		(IEN  | PTD | EN  | M4)) /*GPIO_99 : SPISEL*/\
	MUX_VAL(CP(CCDC_DATA1),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(CCDC_DATA2),		(IDIS | PTD | DIS | M4)) /*GPIO_101 : ABLEN*/\
	MUX_VAL(CP(CCDC_DATA3),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(CCDC_DATA4),		(IDIS | PTD | DIS | M4)) /*GPIO_103 : ETnRST*/\
	MUX_VAL(CP(CCDC_DATA5),		(IEN  | PTD | EN  | M4)) /*GPIO_104 : LNGSEL*/\
	MUX_VAL(CP(CCDC_DATA6),		(IDIS | PTD | DIS | M4)) /*GPIO_105 : DVIPD*/\
	MUX_VAL(CP(CCDC_DATA7),		(IDIS | PTD | DIS | M4)) /*GPIO_106 : VDACPS*/\
	/* RMII */\
	MUX_VAL(CP(RMII_MDIO_DATA),	(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_MDIO_CLK),	(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_RXD0)	,	(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_RXD1),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_CRS_DV),	(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_RXER),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_TXD0),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_TXD1),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_TXEN),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(RMII_50MHZ_CLK),	(IEN  | PTD | EN  | M0)) \
	/* McBSP2 */\
	MUX_VAL(CP(MCBSP2_FSX),		(IEN  | PTD | EN  | M0)) \
	MUX_VAL(CP(MCBSP2_CLKX),	(IEN  | PTD | EN  | M0)) \
	MUX_VAL(CP(MCBSP2_DR),		(IEN  | PTD | EN  | M0)) \
	MUX_VAL(CP(MCBSP2_DX),		(IDIS | PTD | EN  | M0)) \
	/* MMC1 */\
	MUX_VAL(CP(MMC1_CLK),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC1_CMD),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC1_DAT0),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC1_DAT1),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC1_DAT2),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC1_DAT3),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC1_DAT4),		(IEN  | PTD | DIS | M4)) /*GPIO_126 : SDWPM*/\
	MUX_VAL(CP(MMC1_DAT5),		(IEN  | PTD | DIS | M4)) /*GPIO_127 : SDDETM*/\
	MUX_VAL(CP(MMC1_DAT6),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MMC1_DAT7),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	/* MMC2 */\
	MUX_VAL(CP(MMC2_CLK),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_CMD),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT0),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT1),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT2),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT3),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT4),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT5),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT6),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MMC2_DAT7),		(IEN  | PTD | DIS | M0)) \
	/* McBSP3 */\
	MUX_VAL(CP(MCBSP3_DX),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCBSP3_DR),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCBSP3_CLKX),	(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCBSP3_FSX),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	/* UART2 */\
	MUX_VAL(CP(UART2_CTS),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(UART2_RTS),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(UART2_TX),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(UART2_RX),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	/* UART1 */\
	MUX_VAL(CP(UART1_TX),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(UART1_RTS),		(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(UART1_CTS),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(UART1_RX),		(IEN  | PTD | DIS | M0)) \
	/* McBSP4 */\
	MUX_VAL(CP(MCBSP4_CLKX),	(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCBSP4_DR),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCBSP4_DX),		(IDIS | PTD | DIS | M4)) /*GPIO_154 : PDONEM*/\
	MUX_VAL(CP(MCBSP4_FSX),		(IDIS | PTD | EN  | M4)) /*GPIO_155 : DACnPD*/\
	/* McBSP */\
	MUX_VAL(CP(MCBSP1_CLKR),	(IEN  | PTD | DIS | M1)) /*SPI#4 clk*/\
	MUX_VAL(CP(MCBSP1_FSR),		(IEN  | PTD | DIS | M4)) /*GPIO_157 : BKC*/\
	MUX_VAL(CP(MCBSP1_DX),		(IEN  | PTD | DIS | M1)) /*SPI#4 simo*/\
	MUX_VAL(CP(MCBSP1_DR),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCBSP_CLKS),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(MCBSP1_FSX),		(IEN  | PTD | DIS | M1)) /*#SPI#4 cs0*/\
	MUX_VAL(CP(MCBSP1_CLKX),	(IDIS | PTD | DIS | M4)) /*GPIO_162 : AHLTM*/\
	/* UART3 */\
	MUX_VAL(CP(UART3_CTS_RCTX),	(IDIS | PTD | EN  | M7)) \
	MUX_VAL(CP(UART3_RTS_SD),	(IDIS | PTD | EN  | M7)) \
/*	MUX_VAL(CP(UART3_CTS_RCTX),	(IDIS | PTD | DIS | M4)) *//* GPIO_163 *//*Debug*/\
/*	MUX_VAL(CP(UART3_RTS_SD),	(IDIS | PTD | DIS | M4)) *//* GPIO_164 *//*Debug*/\
	MUX_VAL(CP(UART3_RX_IRRX),	(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(UART3_TX_IRTX),	(IDIS | PTD | DIS | M0)) \
	MUX_VAL(CP(USB0_DRVVBUS),	(IEN  | PTU | EN  | M4)) /*GPIO_125 : CONSEL*/\
	/* HECC */\
	MUX_VAL(CP(HECC1_TXD),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(HECC1_RXD),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	/* I2C */\
	MUX_VAL(CP(I2C1_SCL),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(I2C1_SDA),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(I2C2_SCL),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(I2C2_SDA),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(I2C3_SCL),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(I2C3_SDA),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	/* HDQ */\
	MUX_VAL(CP(HDQ_SIO),		(IEN  | PTD | EN  | M4)) /*GPIO_170 : RESSEL*/\
	/* McSPI */\
	MUX_VAL(CP(MCSPI1_CLK),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(MCSPI1_SIMO),	(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(MCSPI1_SOMI),	(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCSPI1_CS0),		(IEN  | PTU | EN  | M0)) \
	MUX_VAL(CP(MCSPI1_CS1),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCSPI1_CS2),		(IDIS | PTD | DIS | M4)) /*GPIO_176 : HS2EN*/\
	MUX_VAL(CP(MCSPI1_CS3),		(IDIS | PTD | DIS | M5)) /*mm_fsusb2_txdat*/\
	MUX_VAL(CP(MCSPI2_CLK),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCSPI2_SIMO),	(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCSPI2_SOMI),	(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCSPI2_CS0),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(MCSPI2_CS1),		(IDIS | PTD | DIS | M5)) /*mm_fsusb2_txen_n*/\
	/* Control and debug */\
	MUX_VAL(CP(SYS_NIRQ),		(IDIS | PTD | DIS | M7)) /*safe_mode*/\
	MUX_VAL(CP(SYS_CLKOUT2),	(IEN  | PTD | EN  | M4)) /*GPIO_186 : AFPROG*/\
	/* ETK (ES2 onwards) */\
	MUX_VAL(CP(ETK_CLK_ES2),	(IDIS | PTD | DIS | M4)) /*GPIO_12 : HS1EN*/\
	MUX_VAL(CP(ETK_CTL_ES2),	(IEN  | PTD | DIS | M5)) /*mm_fsusb1_rxdp*/\
	MUX_VAL(CP(ETK_D0_ES2),		(IEN  | PTD | DIS | M5)) /*mm_fsusb1_rxrcv*/\
	MUX_VAL(CP(ETK_D1_ES2),		(IEN  | PTD | DIS | M5)) /*mm_fsusb1_txse0*/\
	MUX_VAL(CP(ETK_D2_ES2),		(IEN  | PTD | DIS | M5)) /*mm_fsusb1_txdat*/\
	MUX_VAL(CP(ETK_D3_ES2),		(IDIS | PTD | DIS | M4)) /*GPIO_17 : US1SPD*/\
	MUX_VAL(CP(ETK_D4_ES2),		(IDIS | PTD | DIS | M4)) /*GPIO_18 : POLSEL*/\
	MUX_VAL(CP(ETK_D5_ES2),		(IEN  | PTD | DIS | M4)) /*GPIO_19 : HS1INT*/\
	MUX_VAL(CP(ETK_D6_ES2),		(IEN  | PTD | DIS | M4)) /*GPIO_20 : HS2INT*/\
	MUX_VAL(CP(ETK_D7_ES2),		(IEN  | PTD | DIS | M5)) /*mm_fsusb1_txen_n*/\
	MUX_VAL(CP(ETK_D8_ES2),		(IDIS | PTD | DIS | M4)) /*GPIO_22 : US1SUS*/\
	MUX_VAL(CP(ETK_D9_ES2),		(IEN  | PTD | DIS | M5)) /*mm_fsusb1_rxdm*/\
	MUX_VAL(CP(ETK_D10_ES2),	(IDIS | PTD | DIS | M4)) /*GPIO_24 : US2SUS*/\
	MUX_VAL(CP(ETK_D11_ES2),	(IEN  | PTD | DIS | M5)) /*mm_fsusb2_rxdp*/\
	MUX_VAL(CP(ETK_D12_ES2),	(IDIS | PTD | DIS | M4)) /*GPIO_26 : US2SPD*/\
	MUX_VAL(CP(ETK_D13_ES2),	(IEN  | PTD | DIS | M5)) /*mm_fsusb2_rxdm*/\
	MUX_VAL(CP(ETK_D14_ES2),	(IEN  | PTD | DIS | M5)) /*mm_fsusb2_rxrcv*/\
	MUX_VAL(CP(ETK_D15_ES2),	(IEN  | PTD | DIS | M5)) /*mm_fsusb2_txse0*/\
	MUX_VAL(CP(SYS_32K),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_CLKREQ),		(IDIS | PTD | EN  | M4)) /*GPIO_1*/\
	/*SYS_nRESWARM */\
	MUX_VAL(CP(SYS_NRESWARM),     	(IDIS | PTD | DIS | M4)) /*GPIO_30*/\
	MUX_VAL(CP(SYS_BOOT0),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT1),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT2),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT3),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT4),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT5),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT6),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT7),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_BOOT8),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(SYS_CLKOUT1),	(IEN  | PTD | EN  | M4)) /*GPIO_10 : LCDREQ*/\
	/* JTAG */\
	MUX_VAL(CP(JTAG_nTRST),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(JTAG_TCK),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(JTAG_RTCK),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(JTAG_TMS),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(JTAG_TDI),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(JTAG_TDO),		(IEN  | PTD | DIS | M0)) \
	MUX_VAL(CP(JTAG_EMU0),		(IDIS | PTD | EN  | M4)) /*GPIO_11*/\
	MUX_VAL(CP(JTAG_EMU1),		(IDIS | PTD | EN  | M4)) /*GPIO_31*/\
	
/**********************************************************
 * Routine: set_muxconf_regs
 * Description: Setting up the configuration Mux registers
 *              specific to the hardware. Many pins need
 *              to be moved from protect to primary mode.
 *********************************************************/
void set_muxconf_regs(void)
{
	MUX_DEFAULT();
}

void dss_init(void)
{
	unsigned int i=0;
	unsigned int *vram;
	int offset = 0;
	int lcdreq;
	int ressel;
	int afprog;
	int lngsel;
	block_dev_desc_t *dev_desc = NULL;
	long size;

	lcdreq = omap_get_gpio_datain(10);
	ressel = omap_get_gpio_datain(170);
	afprog = omap_get_gpio_datain(186);

	/* Reset Display Subsystem */
/*	*((uint *) 0x48050010) = 0x00000003;*/    /* DSS_SYSCONFIG */

	if(1 == lcdreq) {
		/* Add boot image data */
		vram = (unsigned int *)(0x8FC00000 + offset);
		dev_desc = mmc_get_dev(0);
		if(1 == afprog) {	/* Update Mode */
			fat_register_device(dev_desc, 1);
 			lngsel = omap_get_gpio_datain(104);
 			if(1 != lngsel) {	/* English */
 				size = file_fat_read("screen3", vram, 0);
 			} else {		/* Japanese */
 				size = file_fat_read("screen4", vram, 0);
 			}
		} else {		/* Normal Mode */
			fat_register_device(dev_desc, 2);
			if(ressel)		/* 848x480 */
				size = file_fat_read("screen2", vram, 0);
			else			/* 800x600 */
				size = file_fat_read("screen1", vram, 0);
			if( size < 1 ) {
				fat_register_device(dev_desc, 1);
				if(ressel)		/* 848x480 */
					file_fat_read("screen2", vram, 0);
				else
					file_fat_read("screen1", vram, 0);
				printf("screen: 1st Partition\n");
			} else {
				printf("screen: 2nd Partition\n");
			}
		}
	} else {
		/* Clear image data */
		vram = (unsigned int *)(0x8FC00000 + offset);
		if(ressel) {		/* 848x480 */
			for (i = 0; i < (848*480);i++) {
				*(vram+i) = 0;
			}
		}
		else {
			for (i = 0; i < (800*480);i++) {
				*(vram+i) = 0;
			}
		}
		printf("Disable LCD\n");
	}

	/* Display Controliler */
/*	while(1 != *((uint *)0x48050014)) {
		udelay(1000);
	}
*/
	*((uint *) 0x48050410) = 0x00002015;    /* DISPC_SYSCONFIG */
	*((uint *) 0x48050444) = 0x00000204;    /* DISPC_CONFIG */

	*((uint *) 0x4805046c) = 0x00004000;    /* DISPC_POL_FREQ */
	*((uint *) 0x48050470) = 0x00010002;    /* DISPC_DIVISOR */
	if(ressel)		/* 848x480 */
	{
		*((uint *) 0x48004E40) = 0x0000100D;    /* CM_CLKSEL_DSS */
		*((uint *) 0x48050464) = 0x06F00F6F;    /* DISPC_TIMING_H */
		*((uint *) 0x48050468) = 0x01700607;    /* DISPC_TIMING_V */
		*((uint *) 0x4805047c) = 0x01DF034F;    /* DISPC_SIZE_LCD */
		*((uint *) 0x4805048c) = 0x01DF034F;    /* DISPC_GFX_SIZE */
	}
	else			/* 800x600 */
	{
		*((uint *) 0x48004E40) = 0x0000100B;    /* CM_CLKSEL_DSS */
		*((uint *) 0x48050464) = 0x0570277F;    /* DISPC_TIMING_H */
		*((uint *) 0x48050468) = 0x01700103;    /* DISPC_TIMING_V */
		*((uint *) 0x4805047c) = 0x0257031F;    /* DISPC_SIZE_LCD */
		*((uint *) 0x4805048c) = 0x0257031F;    /* DISPC_GFX_SIZE */
	}

	*((uint *) 0x48050480) = 0x8FC00000;    /* DISPC_GFX_BA0 */
	*((uint *) 0x48050484) = 0x8FC00000;    /* DISPC_GFX_BA1 */
	*((uint *) 0x480504a0) = 0x00000099;    /* DISPC_GFX_ATTRIBUTES */

	udelay(1000);
	*((uint *) 0x48050440) = 0x00018329;    /* DISPC_CONTROL */

	if(1 == lcdreq)
	{
		omap_set_gpio_dataout(101,1);	        /* Main LCD Backlight Power */
	}
}

static int gpmc_config_reset(void)
{
	/*
	 * DEVICESIZE = 0x3 (reserved)
	 * DEVICETYPE = 0x3 (reserved)
	 *
	 * Do not touch CS0 config registers, since ROM code would
	 * have already configured it.
	 */
	__raw_writel( 0x00003c00, GPMC_CONFIG1 + GPMC_CONFIG_CS1);
	__raw_writel( 0x00003c00, GPMC_CONFIG1 + GPMC_CONFIG_CS2);
	__raw_writel( 0x00003c00, GPMC_CONFIG1 + GPMC_CONFIG_CS3);
	__raw_writel( 0x00003c00, GPMC_CONFIG1 + GPMC_CONFIG_CS4);
	__raw_writel( 0x00003c00, GPMC_CONFIG1 + GPMC_CONFIG_CS5);
	__raw_writel( 0x00003c00, GPMC_CONFIG1 + GPMC_CONFIG_CS6);
	__raw_writel( 0x00003c00, GPMC_CONFIG1 + GPMC_CONFIG_CS7);
	return 0;

}
/**********************************************************
 * Routine: gpmc_init
 * Description: Set up gpmc for NOR Flash
 *********************************************************/
int gpmc_init(void)
{
	/*
	 * Reset the CONFIG0 register, especially device_type field.
	 * This is required to make decesions on interfaced flash devices
	 * later in the boot process.
	 *
	 * kernel reads the DEVICETYPE field in detection of NOR or NAND flash
	 * and the reset value of this field is 0, which is NOR. This creates
	 * problem when you have NOR flash as a data flash connected to
	 * different CS.
	 */
	gpmc_config_reset();

	__raw_writel( NOR_GPMC_CONFIG_, GPMC_CONFIG);
	__raw_writel( NOR_GPMC_CONFIG1, GPMC_CONFIG1 + GPMC_CONFIG_CS0);
	__raw_writel( NOR_GPMC_CONFIG2, GPMC_CONFIG2 + GPMC_CONFIG_CS0);
	__raw_writel( NOR_GPMC_CONFIG3, GPMC_CONFIG3 + GPMC_CONFIG_CS0);
	__raw_writel( NOR_GPMC_CONFIG4, GPMC_CONFIG4 + GPMC_CONFIG_CS0);
	__raw_writel( NOR_GPMC_CONFIG5, GPMC_CONFIG5 + GPMC_CONFIG_CS0);

	/* Enable the GPMC Mapping */
	__raw_writel(( ((OMAP34XX_GPMC_CS0_SIZE & 0xF)<<8) |
		((NOR_BASE_ADR>>24) & 0x3F) |
		(1<<6) ),  (GPMC_CONFIG7 + GPMC_CONFIG_CS0));
	delay(2000);

	return 0;
}

typedef int (mmc_boot_addr) (void);
int mmc_boot(unsigned char *buf)
{

       long size = 0;
#ifdef CFG_CMD_FAT
       block_dev_desc_t *dev_desc = NULL;
	int ressel;
	const char *kernel_name;

       dev_desc = mmc_get_dev(0);
	fat_register_device(dev_desc, 1);
	ressel = omap_get_gpio_datain(170);
	if( 1 == ressel ) {
		kernel_name = &kernel_name_848x480[0];
	} else {
		kernel_name = &kernel_name_800x600[0];
	}
        size = file_fat_read(kernel_name, buf, 0);
       if (size == -1) {
               return 0;
       }
# ifdef CONFIG_MMC_HSMMC2 
       printf("\n%ld Bytes Read from eMMC \n", size);
       printf("Starting Linux Kernel from eMMC...\n");
# else
       printf("\n%ld Bytes Read from SD Card \n", size);
       printf("Starting Linux Kernel from SD Card...\n");
# endif
#endif
       return size;
}

/* optionally do something like blinking LED */
void board_hang (void)
{ while (0) {};}
